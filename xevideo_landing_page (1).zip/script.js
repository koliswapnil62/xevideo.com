document.addEventListener("DOMContentLoaded", () => {
  console.log("Xevideo landing page loaded successfully!");
});